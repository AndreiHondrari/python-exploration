

def do_something() -> None:
    print("DO_SOMETHING")
