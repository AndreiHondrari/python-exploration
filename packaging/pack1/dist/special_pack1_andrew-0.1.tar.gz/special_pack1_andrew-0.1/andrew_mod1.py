

def something() -> None:
    print("Andrew says: `something`.")
