

from distutils.core import setup

setup(
    name='special_pack1_andrew',
    version='0.1',
    py_modules=['andrew_mod1'],
    url='https://andreihondrari.com',
    author='Andrei-George Hondrari',
    author_email='andrei.hondrari@gmail.com'
)
